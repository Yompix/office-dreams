@echo off
chcp 65001 >nul
title Новоград: Кино — установка
echo ============================================
echo   НОВОГРАД: КИНО — установка модов и шейдеров
echo ============================================
echo Перед установкой: в TLauncher выбери версию Fabric 1.21.1, запусти её один раз и закрой игру.
echo.
if not exist "%~dp0novograd-0.6.2.jar" (
  echo Сначала распакуй архив в обычную папку, потом запусти УСТАНОВИТЬ.bat оттуда.
  pause
  exit /b
)
set "MC=%APPDATA%\.minecraft"
if not exist "%MC%" (
  echo Не нашёл папку %MC%
  set /p MC="Вставь путь к папке игры (где лежат mods): "
)
if not exist "%MC%\mods" mkdir "%MC%\mods"
if not exist "%MC%\shaderpacks" mkdir "%MC%\shaderpacks"
if not exist "%MC%\config" mkdir "%MC%\config"
echo.
set BIG=N
set STUDIO=N
set SKINS=N
set REPLAY=N
set FX=Y
set SHADERS=true
echo Ноутбук или слабый компьютер (встроенная видеокарта, 8 ГБ памяти и меньше)?
set /p LITE="  Лёгкая сборка — без шейдеров и тяжёлых эффектов, игра не вылетает и не тормозит [Y/N]: "
if /i "%LITE%"=="Y" (
  set FX=N
  set SHADERS=false
  goto :afterask
)
echo Что ещё поставить (Y — да, N — нет):
set /p BIG="  Flashback (запись и монтаж видео, 200 МБ) и AmbientSounds (звуки природы)? [Y/N]: "
set /p SKINS="  Свои скины: CustomSkinLoader + SkinRestorer (скины видно и в онлайне)? [Y/N]: "
:afterask
echo.
echo Удаляю старые версии этих модов (чтобы не было дубликатов)...
del /q "%MC%\mods\novograd-*.jar" >nul 2>&1
del /q "%MC%\mods_old\novograd-*.jar" >nul 2>&1
del /q "%MC%\mods\entityculling-*.jar" >nul 2>&1
del /q "%MC%\mods\fabric-api-*.jar" >nul 2>&1
del /q "%MC%\mods_old\fabric-api-*.jar" >nul 2>&1
del /q "%MC%\mods\sodium-*.jar" >nul 2>&1
del /q "%MC%\mods_old\sodium-*.jar" >nul 2>&1
del /q "%MC%\mods\iris-*.jar" >nul 2>&1
del /q "%MC%\mods_old\iris-*.jar" >nul 2>&1
del /q "%MC%\mods\camerautils-*.jar" >nul 2>&1
del /q "%MC%\mods_old\camerautils-*.jar" >nul 2>&1
del /q "%MC%\mods\freecam-*.jar" >nul 2>&1
del /q "%MC%\mods_old\freecam-*.jar" >nul 2>&1
del /q "%MC%\mods\sound-physics-*.jar" >nul 2>&1
del /q "%MC%\mods_old\sound-physics-*.jar" >nul 2>&1
del /q "%MC%\mods\wakes-*.jar" >nul 2>&1
del /q "%MC%\mods_old\wakes-*.jar" >nul 2>&1
del /q "%MC%\mods\particlerain-*.jar" >nul 2>&1
del /q "%MC%\mods_old\particlerain-*.jar" >nul 2>&1
del /q "%MC%\mods\continuity-*.jar" >nul 2>&1
del /q "%MC%\mods_old\continuity-*.jar" >nul 2>&1
del /q "%MC%\mods\visuality-*.jar" >nul 2>&1
del /q "%MC%\mods_old\visuality-*.jar" >nul 2>&1
del /q "%MC%\mods\cloth-config-*.jar" >nul 2>&1
del /q "%MC%\mods_old\cloth-config-*.jar" >nul 2>&1
del /q "%MC%\mods\lithium-*.jar" >nul 2>&1
del /q "%MC%\mods_old\lithium-*.jar" >nul 2>&1
del /q "%MC%\mods\ferritecore-*.jar" >nul 2>&1
del /q "%MC%\mods_old\ferritecore-*.jar" >nul 2>&1
del /q "%MC%\mods\ImmediatelyFast-*.jar" >nul 2>&1
del /q "%MC%\mods_old\ImmediatelyFast-*.jar" >nul 2>&1
del /q "%MC%\mods\modernfix-*.jar" >nul 2>&1
del /q "%MC%\mods_old\modernfix-*.jar" >nul 2>&1
del /q "%MC%\mods\moreculling-*.jar" >nul 2>&1
del /q "%MC%\mods_old\moreculling-*.jar" >nul 2>&1
del /q "%MC%\mods\Flashback-*.jar" >nul 2>&1
del /q "%MC%\mods_old\Flashback-*.jar" >nul 2>&1
del /q "%MC%\mods\AmbientSounds_*.jar" >nul 2>&1
del /q "%MC%\mods_old\AmbientSounds_*.jar" >nul 2>&1
del /q "%MC%\mods\CreativeCore_*.jar" >nul 2>&1
del /q "%MC%\mods_old\CreativeCore_*.jar" >nul 2>&1
del /q "%MC%\mods\bbs-*.jar" >nul 2>&1
del /q "%MC%\mods_old\bbs-*.jar" >nul 2>&1
del /q "%MC%\mods\CustomSkinLoader_*.jar" >nul 2>&1
del /q "%MC%\mods_old\CustomSkinLoader_*.jar" >nul 2>&1
del /q "%MC%\mods\skinrestorer-*.jar" >nul 2>&1
del /q "%MC%\mods_old\skinrestorer-*.jar" >nul 2>&1
del /q "%MC%\mods\replaymod-*.jar" >nul 2>&1
del /q "%MC%\mods_old\replaymod-*.jar" >nul 2>&1
copy /y "%~dp0novograd-0.6.2.jar" "%MC%\mods\" >nul
echo Скачиваю моды с modrinth.com ...
echo   fabric-api-0.116.17+1.21.1.jar
if not exist "%MC%\mods\fabric-api-0.116.17+1.21.1.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/P7dR8mSH/versions/Mys3P7lK/fabric-api-0.116.17%%2B1.21.1.jar' -OutFile '%MC%\mods\fabric-api-0.116.17+1.21.1.jar'"
echo   sodium-fabric-0.8.13+mc1.21.1.jar
if not exist "%MC%\mods\sodium-fabric-0.8.13+mc1.21.1.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/AANobbMI/versions/SMxNOGZ6/sodium-fabric-0.8.13%%2Bmc1.21.1.jar' -OutFile '%MC%\mods\sodium-fabric-0.8.13+mc1.21.1.jar'"
echo   iris-fabric-1.8.14-beta.1+mc1.21.1.jar
if not exist "%MC%\mods\iris-fabric-1.8.14-beta.1+mc1.21.1.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/YL57xq9U/versions/bAo1Qhte/iris-fabric-1.8.14-beta.1%%2Bmc1.21.1.jar' -OutFile '%MC%\mods\iris-fabric-1.8.14-beta.1+mc1.21.1.jar'"
echo   camerautils-fabric-1.21.1-1.0.16.jar
if not exist "%MC%\mods\camerautils-fabric-1.21.1-1.0.16.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/rrwQMaWQ/versions/ZUEjVQxa/camerautils-fabric-1.21.1-1.0.16.jar' -OutFile '%MC%\mods\camerautils-fabric-1.21.1-1.0.16.jar'"
echo   freecam-fabric-1.3.0+mc1.21.jar
if not exist "%MC%\mods\freecam-fabric-1.3.0+mc1.21.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/XeEZ3fK2/versions/Cg10zLnR/freecam-fabric-1.3.0%%2Bmc1.21.jar' -OutFile '%MC%\mods\freecam-fabric-1.3.0+mc1.21.jar'"
if /i "%FX%"=="Y" (
  echo   sound-physics-remastered-fabric-1.21.1-1.5.2.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/qyVF9oeo/versions/BYhL3BDk/sound-physics-remastered-fabric-1.21.1-1.5.2.jar' -OutFile '%MC%\mods\sound-physics-remastered-fabric-1.21.1-1.5.2.jar'"
)
if /i "%FX%"=="Y" (
  echo   wakes-0.4.1+1.21.1.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/dlNu0RQY/versions/WuY7eJX9/wakes-0.4.1%%2B1.21.1.jar' -OutFile '%MC%\mods\wakes-0.4.1+1.21.1.jar'"
)
if /i "%FX%"=="Y" (
  echo   particlerain-4.0.3+1.21.1-fabric.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/nrikgvxm/versions/GBivJmD5/particlerain-4.0.3%%2B1.21.1-fabric.jar' -OutFile '%MC%\mods\particlerain-4.0.3+1.21.1-fabric.jar'"
)
echo   continuity-3.0.0+1.21.jar
if not exist "%MC%\mods\continuity-3.0.0+1.21.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/1IjD5062/versions/kSPJ4hQv/continuity-3.0.0%%2B1.21.jar' -OutFile '%MC%\mods\continuity-3.0.0+1.21.jar'"
if /i "%FX%"=="Y" (
  echo   visuality-0.7.7+1.21.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/rI0hvYcd/versions/dhKbgdIb/visuality-0.7.7%%2B1.21.jar' -OutFile '%MC%\mods\visuality-0.7.7+1.21.jar'"
)
echo   cloth-config-15.0.140-fabric.jar
if not exist "%MC%\mods\cloth-config-15.0.140-fabric.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/9s6osm5g/versions/HpMb5wGb/cloth-config-15.0.140-fabric.jar' -OutFile '%MC%\mods\cloth-config-15.0.140-fabric.jar'"
echo   lithium-fabric-0.15.4+mc1.21.1.jar
if not exist "%MC%\mods\lithium-fabric-0.15.4+mc1.21.1.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/gvQqBUqZ/versions/N08Z8wog/lithium-fabric-0.15.4%%2Bmc1.21.1.jar' -OutFile '%MC%\mods\lithium-fabric-0.15.4+mc1.21.1.jar'"
echo   ferritecore-7.0.3-fabric.jar
if not exist "%MC%\mods\ferritecore-7.0.3-fabric.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/uXXizFIs/versions/sOzRw3CG/ferritecore-7.0.3-fabric.jar' -OutFile '%MC%\mods\ferritecore-7.0.3-fabric.jar'"
echo   ImmediatelyFast-Fabric-1.6.15+1.21.1.jar
if not exist "%MC%\mods\ImmediatelyFast-Fabric-1.6.15+1.21.1.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/5ZwdcRci/versions/aLnBqxFW/ImmediatelyFast-Fabric-1.6.15%%2B1.21.1.jar' -OutFile '%MC%\mods\ImmediatelyFast-Fabric-1.6.15+1.21.1.jar'"
echo   modernfix-fabric-5.25.1+mc1.21.1.jar
if not exist "%MC%\mods\modernfix-fabric-5.25.1+mc1.21.1.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/nmDcB62a/versions/NnNX8LBn/modernfix-fabric-5.25.1%%2Bmc1.21.1.jar' -OutFile '%MC%\mods\modernfix-fabric-5.25.1+mc1.21.1.jar'"
echo   moreculling-fabric-1.21.1-1.0.11.jar
if not exist "%MC%\mods\moreculling-fabric-1.21.1-1.0.11.jar" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/51shyZVL/versions/zze1l7gB/moreculling-fabric-1.21.1-1.0.11.jar' -OutFile '%MC%\mods\moreculling-fabric-1.21.1-1.0.11.jar'"
echo   MakeUp-UltraFast-9.6.zip
if not exist "%MC%\shaderpacks\MakeUp-UltraFast-9.6.zip" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/izsIPI7a/versions/t4YRxQug/MakeUp-UltraFast-9.6.zip' -OutFile '%MC%\shaderpacks\MakeUp-UltraFast-9.6.zip'"
echo   ComplementaryReimagined_r5.9.3.zip
if not exist "%MC%\shaderpacks\ComplementaryReimagined_r5.9.3.zip" powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/HVnmMxH1/versions/Bqen1mJX/ComplementaryReimagined_r5.9.3.zip' -OutFile '%MC%\shaderpacks\ComplementaryReimagined_r5.9.3.zip'"
if /i "%BIG%"=="Y" (
  echo   Flashback-0.39.10-for-MC1.21.1.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/4das1Fjq/versions/nPzvTtsX/Flashback-0.39.10-for-MC1.21.1.jar' -OutFile '%MC%\mods\Flashback-0.39.10-for-MC1.21.1.jar'"
)
if /i "%BIG%"=="Y" (
  echo   AmbientSounds_FABRIC_v6.3.11_mc1.21.1.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/fM515JnW/versions/54u7eI2t/AmbientSounds_FABRIC_v6.3.11_mc1.21.1.jar' -OutFile '%MC%\mods\AmbientSounds_FABRIC_v6.3.11_mc1.21.1.jar'"
)
if /i "%BIG%"=="Y" (
  echo   CreativeCore_FABRIC_v2.13.48_mc1.21.1.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/OsZiaDHq/versions/v7fZmKvM/CreativeCore_FABRIC_v2.13.48_mc1.21.1.jar' -OutFile '%MC%\mods\CreativeCore_FABRIC_v2.13.48_mc1.21.1.jar'"
)
if /i "%STUDIO%"=="Y" (
  echo   bbs-2.4-1.21.1.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/HNsMvuaQ/versions/GKRCswnb/bbs-2.4-1.21.1.jar' -OutFile '%MC%\mods\bbs-2.4-1.21.1.jar'"
)
if /i "%SKINS%"=="Y" (
  echo   CustomSkinLoader_Universal-15.1.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/idMHQ4n2/versions/yyYvYfZI/CustomSkinLoader_Universal-15.1.jar' -OutFile '%MC%\mods\CustomSkinLoader_Universal-15.1.jar'"
)
if /i "%SKINS%"=="Y" (
  echo   skinrestorer-2.11.1+1.21-fabric.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/ghrZDhGW/versions/lvRKajvV/skinrestorer-2.11.1%%2B1.21-fabric.jar' -OutFile '%MC%\mods\skinrestorer-2.11.1+1.21-fabric.jar'"
)
if /i "%REPLAY%"=="Y" (
  echo   replaymod-1.21-2.6.28.jar
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.modrinth.com/data/Nv2fQJo5/versions/DKvQ3lQq/replaymod-1.21-2.6.28.jar' -OutFile '%MC%\mods\replaymod-1.21-2.6.28.jar'"
)
if /i "%LITE%"=="Y" if not exist "%MC%\config\novograd.json" echo {"graphics":1,"hudScale":0.85}> "%MC%\config\novograd.json"
echo enableShaders=%SHADERS%> "%MC%\config\iris.properties"
echo shaderPack=MakeUp-UltraFast-9.6.zip>> "%MC%\config\iris.properties"
if not exist "%MC%\mods\fabric-api-*.jar" (
  echo ОШИБКА: Fabric API не скачался. Проверь интернет и запусти УСТАНОВИТЬ.bat ещё раз.
  pause
  exit /b
)
rmdir "%MC%\mods_old" >nul 2>&1
echo.
echo Готово! Запускай в TLauncher версию Fabric 1.21.1.
echo В игре: Новый мир - Ещё - Тип мира «Новоград: Город».
echo Шейдеры: включён быстрый MakeUp Ultra Fast. Хочешь красивее — Настройки - Графика - Шейдеры - Complementary.
pause
